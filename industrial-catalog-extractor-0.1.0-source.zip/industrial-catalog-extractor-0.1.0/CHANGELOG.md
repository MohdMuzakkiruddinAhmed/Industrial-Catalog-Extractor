# Changelog

All notable project changes are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and releases use
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned

- Manifest-pinned page-window campaign execution.
- Isolated work-unit outputs and deterministic release merge.
- Human-graded extraction and retrieval evaluation on redistributable data.

## [0.1.0] - 2026-08-07

### Added

- Evidence-preserving PDF routing and native/VLM extraction pipeline.
- Schema-constrained product parsing, source guards, and typed validation.
- Two-tier SQLite knowledge base with citation-bearing retrieval.
- Deterministic offline demonstration and synthetic two-page catalog.
- NVIDIA A100 deployment, monitoring, checkpoint, and bounded benchmark scripts.
- Architecture, research, reproducibility, deployment, and governance documents.
- Hash-locked Python environments, CI workflows, container definition, and source
  release builder.

### Validation

- More than 140 automated tests pass with at least 87% statement coverage.
- A bounded 20-document run and a hardened two-document replay are documented;
  neither is presented as a complete 17,837-page corpus campaign.

[Unreleased]: https://github.com/OWNER/industrial-catalog-extractor/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/OWNER/industrial-catalog-extractor/releases/tag/v0.1.0
