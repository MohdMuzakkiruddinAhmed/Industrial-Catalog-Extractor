# Publishing checklist

Complete these items before the first public GitHub push.

- [ ] Replace `OWNER` placeholders in `CHANGELOG.md`, add real `[project.urls]` to
  `pyproject.toml`, and update any badges or links added later.
- [ ] Replace the generic contributor entry in `CITATION.cff` with the preferred
  author name, affiliation, ORCID, and repository URL.
- [ ] Confirm Apache-2.0 is the intended code license.
- [ ] Review `THIRD_PARTY_MODELS.md` and `THIRD_PARTY_NOTICES.md`; obtain any
  commercial PyMuPDF/MuPDF license required by the intended distribution model.
- [ ] Confirm every shared catalog is owned, licensed, or redistribution-cleared.
- [ ] Keep source PDFs, extracted text, embeddings, model weights, credentials,
  databases, and run artifacts out of Git.
- [ ] Run `python scripts/build_source_release.py` and upload only the generated
  allowlisted ZIP or an equivalently reviewed Git tree.
- [ ] Run the clean-environment commands in `docs/REPRODUCIBILITY.md`.
- [ ] Scan the staged tree and Git history with a secret scanner before publishing.
- [ ] Create a release tag matching `src/industrial_catalog/__init__.py` and update
  the changelog comparison links.

The checked-in corpus statistics and aggregate measurements are research evidence,
not a redistribution grant for the underlying PDFs or model responses.
